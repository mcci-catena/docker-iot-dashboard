const express = require("express");
const res = require("express/lib/response");
const dotenv = require('dotenv');
const fs = require('fs')

const app = express();

dotenv.config();

app.use(express.json());




app.get("/info", (req, res) => {
    res.send("Version API is running ...");
});

app.get("/getver", (req, res) => {
    fs.readFile('/vers/ver_info', 'utf8', (err, data) =>  {
        if(err)
        {
            console.error(err)
            res.send("File Read Error")
            return
        }
        //console.log(data)
        res.send(data)
    })
});

const PORT = process.env.PORT_CONFIG || 7000

app.listen(PORT, console.log('Server start to listen Port ' + PORT));
